This project is made to simplify work done at pharmacy 
*Download the zip file
*cpp codes and txt files are saved in codes sunfolder
*run oops.cpp

|oops.cpp|
This code is divided into 3 parts 
1.Admin
2.Receptionist
3.Coustomer

In admin we have
  •	Create data and save in file
  #done by Jaswanth Krishna,Kavya sree,Himaja
  Creating the bill (tablets ,mrp) ,printing data and saving in file
  •	Medicines data
  #done by Kavya sree
  Printing all medicine data name , stock, manucature,expiry,stock
  •	Symptoms data
  #Done by Jaswanth Krishna
  Saving and printing symptoms using file management
  •	Transactions on a particular date
  #done by kavya sree
  Printing all transaction done in a particular day by reading from file
  •	All transactions
  #done by Kavya sree
  Printing all transaction done and saved in the file
  
In reception we have
  •	Create data and save in file
  #done by Jaswanth Krishna,Kavya sree,Himaja
  Creating the bill (tablets ,mrp) ,printing data and saving in file
  •	Medicines data
  #done by Kavya sree
  Printing all medicine data name , stock, manucature,expiry,stock
  •	Last 5 transaction
  #done by Himaja
  Printing latest 5 transactions done which are saved in file
In customer we have 
  •	Total transaction no. of a person
  #done by Jaswanth krishna
  No. Of transaction done by a particular person
  •	Transactions of the person
  #done by Jaswanth krishna
  Printing the transaction details done by a particular person


